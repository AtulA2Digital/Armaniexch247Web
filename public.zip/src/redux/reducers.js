import { combineReducers } from "redux";
import CricketReducer from "./CricketApi/reducers";

export default combineReducers({
  CricketReducer,
});
