import { ReactComponent as DataRange } from "./Date_range_fill.svg";
import { ReactComponent as Location } from "./location.svg";

export { DataRange };
export { Location };
