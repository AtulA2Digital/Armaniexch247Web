import React from "react";
import { useParams } from "react-router-dom";

const Venue_Details = () => {
  const { venueId } = useParams();
  return <div>Venue_Details</div>;
};

export default Venue_Details;
