import React from "react";

const HeadtoHead = () => {
  return <div>Head To Head</div>;
};

export default HeadtoHead;
